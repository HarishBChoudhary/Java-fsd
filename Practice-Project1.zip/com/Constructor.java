package com;

public class Constructor {
	
	 int a;
	 String s;
	double d;
	int t;

	Constructor(int t, double d) {

		this.t = t;
		this.d = d;
	}

	public static void main(String[] args) {
		
		Constructor c = new Constructor(10, 20.5);
		
		System.out.println("Values assign by Implicit constructor");
		System.out.println(c.a);
		System.out.println(c.s);
		System.out.println("Values assign by Explicit constructor");
		System.out.println(c.t);
		System.out.println(c.d);
	}
}
