package com;

public class StringBufer {

	public static void main(String[] args) {
		String  s="HArisha";
		StringBuilder sb = new StringBuilder(s);
		StringBuffer sf=new StringBuffer(sb);
		System.out.println(s);
		System.out.println(sb);
		System.out.println(sf);

	}
}
