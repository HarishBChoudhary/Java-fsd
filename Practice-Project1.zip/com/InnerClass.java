package com;

interface Calculator {
	void add(int a, int b);

	int mul(int a, int b);

}

public class InnerClass {

	public static void main(String[] args) {
		Calculator c = new Calculator() {

			@Override
			public int mul(int a, int b) {
				int sum = a * b;
				return sum;
			}

			@Override
			public void add(int a, int b) {
				int sum = a + b;
				System.out.println("Sum of " + a + " and " + b + " is " + sum);

			}
		};
		c.add(10, 20);
		System.out.println("Product is " + c.mul(10, 20));
	}

}
