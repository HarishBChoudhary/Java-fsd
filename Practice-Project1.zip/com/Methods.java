package com;

public class Methods {

	public static void add(int a, int b) {
		System.out.println("Sum:" + a + b);
	}

	public static int mul(int a, int b) {
		add(10,20);
		return a * b;
		
	}

	public static void sub() {
		int a = 10, b = 2;
		System.out.println("Subtraction Of 10 and 2:" + (a - b));

	}

	public static int div() {
		int a = 50, b = 20;
		return a / b;

	}

	public static void main(String[] args) {
		add(10, 58);
		System.out.println("Multiplication of 88 and 28 is:" + mul(88, 28));
		sub();
		System.out.println("Division of 50 and 20 is:" + div());
	}
}
