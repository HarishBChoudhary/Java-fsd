package com;
import java.util.*;
public class ArrayL {
	public static void main(String[] args) {

		ArrayList l = new ArrayList();

		l.add(20);
		l.add("Harish B Choudhary");
		l.add(null);
		l.add('@');
		l.add(2.5);
		l.add(577101);
		for (int i = 0; i < l.size(); i++) {
			System.out.println(l.get(i));
		}
		System.out.println(l);
	}
}
