package com;
import java.util.regex.Matcher; 
import java.util.regex.Pattern; 
import java.util.*; 

public class EmailValidator {
	

	// Java program to check if an email address 
	// is valid using Regex. 
	
	
		public static boolean isValid(String email) 
		{ 
			String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
								"[a-zA-Z0-9_+&*-]+)*@" + 
								"(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
								"A-Z]{2,7}$"; 
								
			Pattern p = Pattern.compile(emailRegex); 
			if (email == null) 
				return false; 
			return p.matcher(email).matches(); 
		} 

		public static void main(String[] args) 
		{ 
			ArrayList<String> address = new ArrayList<>(); 
				Scanner sc=new Scanner(System.in);
			System.out.println("Enter 3 email\n-------------------------------");
				
				for (int i = 0; i < 3; i++) {
					System.out.println("Enter the email");
					address.add(sc.next()); 
				}
				sc.close();
			for(String i : address){ 
				if (isValid(i)) 
					System.out.println(i + " - Valid"); 
				else
					System.out.println(i + " - InValid"); 
			} 
		} 
	} 


