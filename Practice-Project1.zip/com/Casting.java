package com;

public class Casting {
	public static void main(String[] args) {
		
		char c = 'a';
		int a = c;// implicit type casting
		System.out.println(a);
	 
		double d=10.101;
		int x=(int)d;//explicit type casting
		System.out.println(x);
	}
}
