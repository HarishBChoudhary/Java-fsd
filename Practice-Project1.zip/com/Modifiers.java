package com;

public class Modifiers {

	private int a = 10;
	protected int b = 100;
	public String s = "Harisha";
	double d = 125.5;

	public static void main(String[] args) {

		Modifiers m = new Modifiers();
		System.out.println(m.a);
		System.out.println(m.b);
		System.out.println(m.s);
		System.out.println(m.d);

	}
}
class M1 extends Modifiers{
	public static void main(String[] args) {
		Modifiers m = new Modifiers();
		//System.out.println(m.a);  //private members cannot be accessed
		System.out.println(m.b);
		System.out.println(m.s);
		System.out.println(m.d);

	}
}