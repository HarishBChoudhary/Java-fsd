package com;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Student {
	String name;
	int age;
	char gender;

	public Student(String name, int age, char gender) {
		super();
		this.name = name;
		this.age = age;
		this.gender = gender;
	}

	@Override
	public String toString() {

		return name + ":" + age;
	}
}

 class Solution {

	public static void main(String[] args) {
		Map<String, Student> m = new TreeMap<String, Student>();
		m.put("Harish", new Student("Harish", 22, 'M'));
		m.put("Raju", new Student("Raju", 23, 'M'));
		m.put("Rani", new Student("Rani", 20, 'F'));

		Set<String> key = m.keySet();
		for (String s : key) {
			System.out.println(m.get(s));
		}
	}

}
