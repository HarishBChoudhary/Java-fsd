package com;

import java.util.Scanner;

public class Array {
	public static void main(String[] args) {
		int sum1 = 0, sum2 = 0;
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[][] a = new int[n][n];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (i == j) {
					sum1 = sum1 + a[i][j];
				} else if (i + j == n - 1) {
					sum2 = sum2 + a[i][j];
				}
			}
		}
		System.out.println(Math.abs(sum1 - sum2));
	}

}
