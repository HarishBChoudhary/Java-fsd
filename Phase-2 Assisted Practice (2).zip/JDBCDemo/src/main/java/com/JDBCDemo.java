package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.cj.xdevapi.Statement;

/**
 * Servlet implementation class JDBCDemo
 */
public class JDBCDemo extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");

		PrintWriter pw = response.getWriter();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "root");

			java.sql.Statement s = c.createStatement();

			ResultSet rs = s.executeQuery("Select *from orders");

			pw.println("Query Results are:<hr>");
			pw.write("<table border=1>");
			pw.write("<th>ID<th>AMOUNT<th>CUSTOMER NAME");

			while (rs.next()) {

				int id = rs.getInt("order_id");
				float amt = rs.getFloat("Amount");
				String name = rs.getString("customer_name");

				pw.printf("<tr> <td> %s <td> %s <td> %s", id, amt, name);
			}
			pw.write("</table>");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

}
