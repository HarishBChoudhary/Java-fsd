package filters;

import jakarta.servlet.Filter;

import jakarta.servlet.http.HttpFilter;
import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

/**
 * Servlet Filter implementation class ValidationFilter
 */
public class ValidationFilter extends HttpFilter implements Filter {
       
    
    public ValidationFilter() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void destroy() {

	
	}


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter pw=response.getWriter();
		String pan=request.getParameter("pan");
		
		System.out.println("Hi from Filter");
		
		if(pan==null||!pan.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}")) {
			request.getRequestDispatcher("index.html").include(request, response);
		pw.println("<span style='color:red;'>Invalid PAN No.</span>");
		}
		else {
			request.setAttribute("pan", pan);
			chain.doFilter(request, response);
			System.out.println("Bye from Servlet");
		}
		
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
