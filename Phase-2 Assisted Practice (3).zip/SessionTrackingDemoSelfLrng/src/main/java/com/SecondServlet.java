package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import dto.User;

/**
 * Servlet implementation class SecondServlet
 */
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		//false means indicating that we don't want to create a new session, but the session that was started
		//from the firstServlet,here we are getting the same reference.
		HttpSession session=request.getSession(false);
		
		if(session !=null) {
		User u=(User) session.getAttribute("user");
		u.setAge((Integer.parseInt(request.getParameter("age"))));
		u.setEmail(request.getParameter("email"));
		
		session.setAttribute("user", u);
		response.sendRedirect("three.html");
		}
	}

}
