package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

import dto.User;

/**
 * Servlet implementation class SummaryServlet
 */
public class SummaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		


		
		//false means indicating that we don't want to create a new session, but the session that was started
		//from the firstServlet,here we are getting the same reference.
		HttpSession session=request.getSession(false);
		
		if(session !=null) {
		User u=(User) session.getAttribute("user");
		u.setCity(request.getParameter("city"));
		u.setContact(Long.parseLong(request.getParameter("contact")));
		
		PrintWriter pw=response.getWriter();
		pw.println("<h2> Hello "+u.getEmail()+" </h2>");
		pw.println("<h3> Details.. "+u+" </h3>");
		pw.println("<h4> Session Id is "+session.getId()+" </h4>");
		pw.println("<h4> Session created at "+session.getCreationTime()+" </h4>");
		pw.close();
		session.invalidate();
		
		
		}
	
	}

}
