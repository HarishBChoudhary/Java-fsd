package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class UserLoginFormProcessing
 */

@WebServlet("/form-processing-servlet")
public class UserLoginFormProcessing extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
PrintWriter pw = response.getWriter(); 
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		String rememberMe = request.getParameter("rememberMe");
		
		System.out.printf(" user submitted  username=%s password=%s rememberMe=%s \n", username, password,rememberMe );	
		
		pw.write("Hey "+ username + ", thanks for logging in!");
		
		response.setHeader("training-by","simplilearn");
		
		pw.close();

	}

}
